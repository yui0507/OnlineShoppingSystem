from itertools import product
import json
from flask import (Flask, redirect, render_template,
request, url_for, abort)
from lib.client import read_all_product, query_product, replenish_stock, purchase_product

app = Flask(__name__)

# Error handler for http error
@app.errorhandler(404)
def page_not_found(err):
    return render_template("result.html", result_message = "ERROR 404: Ops! the page doesn't exist. If you enter the URL yourself, please check the spelling"), 404

@app.errorhandler(405)
def page_not_found(err):
    return render_template("result.html", result_message = "ERROR 405: Method not allowed. Enter the URL yourself is not allowed for this request"), 404

@app.errorhandler(500)
def internal_error(err):
    return render_template("result.html", result_message = "ERROR 500: Ops! Seems like the server have internal problem"), 500

# Front page of the website, show all the product in the data file
@app.route("/")
def product_display():
    all_product_data = read_all_product()
    exe_id = all_product_data[0]["exe_id"]
    all_product_data.pop(0)
    products = [(item["product_id"], item["description"], item["price"], item["stock"], url_for("replenish_page", id=int(item["product_id"]) + 1), 
                url_for("purchase_page", id=int(item["product_id"]) + 1)) for item in all_product_data]
    return render_template("query.html", exe_id = exe_id, show_result = True, result_message = "Here is all the product:", product_found = True, products = products), 200

# Handle the query from user input
@app.route("/query")
def query_page():
    id = request.args.get("product_id", "").encode("utf-8")
    # No input from the user or first time load the query_page
    if id is None or len(id) == 0:
        return redirect("/")
    else:
        # Input check pass
        if  id.isdigit(): # (id is integer and greater than 0)
            all_product_data = query_product(int(id)) # Get the web service response
            exe_id = all_product_data[0]["exe_id"]
            if all_product_data[0]["msg"] == "Product not found":
                return render_template("query.html", exe_id = exe_id, show_result = True, result_message = all_product_data[0]["msg"], product_found = False), 404
            else:
                data = all_product_data[1]
                products = [(data["product_id"], data["description"], data["price"], data["stock"], 
                            url_for("replenish_page", id=int(data["product_id"]) + 1), url_for("purchase_page", id=int(data["product_id"]) + 1))]
                return render_template("query.html", exe_id = exe_id, show_result = True, result_message = all_product_data[0]["msg"], product_found = True, products = products), 200
        else:
            return render_template("query.html", show_result = True, result_message = "Invalid input: Product ID should be positive integer", product_found = False), 400

def is_product_exist(id):
    all_product_data = query_product(int(id))
    exe_id = all_product_data[0]["exe_id"]
    if all_product_data[0]["msg"] == "Product not found":
        return False
    else:
        return True

# Generate the replenish page
@app.route("/replenish/<int:id>")
def replenish_page(id):
    all_product_data = query_product(int(id))
    exe_id = all_product_data[0]["exe_id"]
    if all_product_data[0]["msg"] == "Product not found":
        abort(404)
    else:
        data = all_product_data[1]
        return render_template("replenish.html", exe_id = exe_id, product_id = data["product_id"], description = data["description"], 
                            price = data["price"], stock = data["stock"], warning = False), 200

# Render the result for replenish process
def handle_replenish_result(id, result, status):
    all_product_data = query_product(int(id))
    exe_id = all_product_data[0]["exe_id"]
    if all_product_data[0]["msg"] == "Product not found":
        abort(404)
    else:
        data = all_product_data[1]
        return render_template("replenish.html", exe_id = exe_id, product_id = data["product_id"], description = data["description"], 
                        price = data["price"], stock = data["stock"], warning = True, warning_message = result), status

# Handle the replenish from user input
@app.route("/replenish/handle/<int:id>", methods=["POST"])
def handle_replenish(id):
    stock = request.form["stock"].strip()
    data = {"stock" : stock}
    server_resp = replenish_stock(int(id), data)
    exe_id = server_resp["exe_id"]
    return handle_replenish_result(id, server_resp["msg"], 200)

# Generate the purchase page 
@app.route("/purchase/<int:id>")
def purchase_page(id):
    if is_product_exist(id):
        all_product_data = query_product(int(id))
        exe_id = all_product_data[0]["exe_id"]
        print(exe_id)
        data = all_product_data[1]
        return render_template("purchase.html", exe_id = exe_id, product_id = data["product_id"], description = data["description"], 
                            price = data["price"], stock = data["stock"], warning = False), 200
    else:
        abort(404)

# Render the result of purchase 
def handle_purchase_result(id, result, status):
    all_product_data = query_product(int(id))
    exe_id = all_product_data[0]["exe_id"]
    data = all_product_data[1]
    return render_template("purchase.html", exe_id = exe_id, product_id = data["product_id"], description = data["description"], 
                        price = data["price"], stock = data["stock"], warning = True, warning_message = result), status

# Handle the purchase process
@app.route("/purchase/handle/<int:id>", methods=["POST"])
def handle_purchase(id):
    quantity = request.form["quantity"].strip()
    credit_card = request.form["credit_card"].strip()

    data = {"quantity" : quantity, "credit_card" : credit_card}
    result = purchase_product(id, data)

    return handle_purchase_result(id, result["msg"], 200)

if __name__ == "__main__":
    app.run(port=8000)
