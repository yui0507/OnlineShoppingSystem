from itertools import product
import json
import re
from urllib import response
from flask import Flask, jsonify, request, abort, render_template
import socket
import hashlib
import threading as thread
from urllib.error import HTTPError
from lib.storage import load_product, save_product, load_credit_card, save_credit_card

app = Flask(__name__)

EXE_ID = ""
HOST = "time-b-b.nist.gov"
PORT = 13

PRODUCT_LOCK = thread.Lock()
CREDIT_CARD_LOCK = thread.Lock()
PURCHASE_LOCK = thread.Lock()

def get_daytime(host, port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((host, port))
        data = s.recv(1024)
    return data.decode('utf-8').strip()

def gen_execution_id():
    time_str = get_daytime(HOST, PORT)
    exe_id = hashlib.sha256(time_str.encode("utf-8")).hexdigest()
    return exe_id

def handle_load_product():
    PRODUCT_LOCK.acquire()
    products = load_product()
    PRODUCT_LOCK.release()
    return products

def handle_save_product(products):
    PRODUCT_LOCK.acquire()
    save_product(products)
    PRODUCT_LOCK.release()
    return

def handle_load_credit_card():
    CREDIT_CARD_LOCK.acquire()
    credit_cards = load_credit_card()
    CREDIT_CARD_LOCK.release()
    return credit_cards

def hanlde_save_credit_card(credit_card):
    CREDIT_CARD_LOCK.acquire()
    save_credit_card(credit_card)
    CREDIT_CARD_LOCK.release()
    return 

def update_stock(id, stock):
    products = handle_load_product()
    for item in products:
        if int(item["product_id"]) == id - 1:
            item["stock"] += stock
            handle_save_product(products)
            return True
    return False

def check_stock(id, quantity):
    products = handle_load_product()
    for item in products:
        if int(item["product_id"]) == id - 1 and item["stock"] >= quantity:
            return True
    return False

def get_product_price(id):
    products = handle_load_product()
    for item in products:
        if int(item["product_id"]) == id - 1:
            return int(item["price"])
    return None

def is_product_exist(id):
    products = handle_load_product()
    for item in products:
        if int(item["product_id"]) == id - 1:
            return True
    return False

def get_product(id):
    products = handle_load_product()
    for item in products:
        if int(item["product_id"]) == int(id) - 1:
            return item
    return None

# Simulate the request to the payment gateway for transaction
def handle_credit_card_transaction(credit_card, amount):
    cards = handle_load_credit_card()
    for item in cards:
        if int(item["credit_card_num"]) == int(credit_card):
            if item["amount"] >= amount:
                item["amount"] -= amount
                hanlde_save_credit_card(cards)
                return True
    return False

@app.route("/api/products", methods=["GET"])
def get_all_product():
    resp = handle_load_product()
    resp.insert(0, {"exe_id" : EXE_ID, "status" : 200})
    return jsonify(resp), 200

@app.route("/api/query/<int:id>", methods=["GET"])
def handle_query(id):
    resp = [{
        "exe_id" : EXE_ID,
        "msg" : "Product not found",
        "status" : 404
    }]
    if is_product_exist(id):
        resp[0]["msg"] = "Product found"
        resp.append(get_product(id))
        resp[0]["status"] = 200
        return jsonify(resp), 200
    else:
        return jsonify(resp), 404

@app.route("/api/replenish/<int:id>", methods=["POST"])
def handle_replenish(id):
    resp = {
        "exe_id" : EXE_ID,
        "msg" : "ERROR: Stock update failed",
        "status" : 200
    }
    data = json.loads(request.data)
    stock = data.get("stock")
    if not stock:
        resp["msg"] = "Invalid input: Stock can not be empty"
        resp["status"] = 400
        return jsonify(resp), 400

    if not stock.isdigit():
        resp["msg"] = "Invalid input: Stock needed to be positive integer"
        resp["status"] = 400
        return jsonify(resp), 400

    stock = int(stock)

    if is_product_exist(id):
        if update_stock(id, stock):
            resp["msg"] = "Stock updated"
            return jsonify(resp), 200
        else:
            resp["msg"] = "Stock update failed: Database not responding"
            return jsonify(resp), 200
    else:
        resp["msg"] = "Product not found"
        resp["status"] = 404
        return jsonify(resp), 404

@app.route("/api/purchase/<int:id>", methods=["POST"])
def purchase_process(id):
    PURCHASE_LOCK.acquire()
    data = json.loads(request.data)
    result =  handle_purchase(id, data)
    PURCHASE_LOCK.release()
    return result

def handle_purchase(id, data):
    resp = {
        "exe_id" : EXE_ID,
        "msg" : "",
        "status" : 200
    }
    data_quantity = data.get("quantity")
    data_credit_card = data.get("credit_card")
    if not data_quantity or not data_credit_card:
        resp["msg"] = "Invalid input: Qauntity or credit card can not be empty"
        resp["status"] = 400
        return jsonify(resp), 400

    if not data_quantity.isdigit():
        resp["msg"] = "Invalid input: Stock needed to be positive integer"
        resp["status"] = 400
        return jsonify(resp), 400

    if not len(data_credit_card) == 16:
        resp["msg"] = "Invalid input: Credit card number need to be 16 digit integer"
        resp["status"] = 400
        return jsonify(resp), 400

    quantity = int(data_quantity)
    credit_card = int(data_credit_card)    
    
    if check_stock(id, quantity) == False:
        resp["msg"] = "ERROR: Product stock is insufficient"
        return jsonify(resp), 400
    else:  
        product_price = get_product_price(id)
        if handle_credit_card_transaction(credit_card, quantity * product_price):
            update_stock(id, -abs(quantity))
            resp["msg"] = f"Purchase success: product id: {id}, quantity: {quantity}, Credit card no: {credit_card}"
            return jsonify(resp), 200
        else:
            resp["msg"] = "ERROR: Invalid credit card or amount is not sufficient"
            resp["status"] = 400
            return jsonify(resp), 400
    
if __name__ == "__main__":
    EXE_ID = gen_execution_id()
    app.run()