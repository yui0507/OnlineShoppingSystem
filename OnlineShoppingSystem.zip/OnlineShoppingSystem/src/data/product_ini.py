import json
import os.path

SAVE_PATH = './src/data'
FILENAME = "products.json"
FULL_FILENAME = os.path.join(SAVE_PATH, FILENAME)

products = [{
        "product_id" : 0,
        "description" : "iPhone 13 mini 128GB",
        "price" : 5999.0,
        "stock" : 1
    }, {
        "product_id" : 1,
        "description" : "iPhone 13 mini 256GB",
        "price" : 6799.0,
        "stock" : 1
    }, {
        "product_id" : 2,
        "description" : "iPhone 13 mini 512GB",
        "price" : 8499.0,
        "stock" : 1
    }, {
        "product_id" : 3,
        "description" : "iPhone 13 128GB",
        "price" : 6799.0,
        "stock" : 1
    }, {
        "product_id" : 4,
        "description" : "iPhone 13 256GB",
        "price" : 7599.0,
        "stock" : 1
    }, {
        "product_id" : 5,
        "description" : "iPhone 13 512GB",
        "price" : 9299.0,
        "stock" : 1
    }, {
        "product_id" : 6,
        "description" : "iPhone 13 Pro 128GB",
        "price" : 8499.0,
        "stock" : 1
    }, {
        "product_id" : 7,
        "description" : "iPhone 13 Pro 256GB",
        "price" : 9299.0,
        "stock" : 1
    }, {
        "product_id" : 8,
        "description" : "iPhone 13 Pro 519GB",
        "price" : 10999.0,
        "stock" : 1
    }, {
        "product_id" : 9,
        "description" : "Use For Unit Test Do NOT Update the stock thanks",
        "price" : 12699.0,
        "stock" : 10
    }]

with open(FULL_FILENAME, "w") as file:
    json.dump(products, file, indent=4)
with open(FULL_FILENAME) as file:
    load_data = json.load(file)
print(load_data)
print("-- Product Data loaded --")