import json
import os.path

SAVE_PATH = './src/data'
FILENAME = "credit_card.json"
FULL_FILENAME = os.path.join(SAVE_PATH, FILENAME)



products = [{
        "credit_card_num" : 1234123412341234,
        "amount" : 100000,
    }, {
        "credit_card_num" : 5678567856785678,
        "amount" : 1000000,
    }]

with open(FULL_FILENAME, "w") as file:
    json.dump(products, file, indent=2)
with open(FULL_FILENAME) as file:
    load_data = json.load(file)
print(load_data)
print("-- Credit card Data loaded --")