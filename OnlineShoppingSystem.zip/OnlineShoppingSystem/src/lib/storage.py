from itertools import product
import json
import os.path
import threading as thread

# SAVE_PATH = './src/data'
PRODUCT_FILENAME = "products.json"
# FULL_PRODUCT_FILENAME = os.path.join(SAVE_PATH, PRODUCT_FILENAME)

CREDIT_FILENAME = "credit_card.json"
# FULL_CREDIT_FILENAME = os.path.join(SAVE_PATH, CREDIT_FILENAME)

SAVE_DIR = os.path.dirname(__file__)
FULL_PRODUCT_FILENAME = f"{SAVE_DIR}/../data/{PRODUCT_FILENAME}"
FULL_CREDIT_FILENAME = f"{SAVE_DIR}/../data/{CREDIT_FILENAME}"

STORAGE_PRODUCT_LOCK = thread.Lock()
STORAGE_CREDIT_CARD_LOCK = thread.Lock()

def load_product():
    STORAGE_PRODUCT_LOCK.acquire()
    products = load_product_from_file()
    STORAGE_PRODUCT_LOCK.release()
    return products

def save_product(product):
    STORAGE_PRODUCT_LOCK.acquire()
    save_product_to_file(product)
    STORAGE_PRODUCT_LOCK.release()
    return 

def load_credit_card():
    STORAGE_CREDIT_CARD_LOCK.acquire()
    credit_card = load_credit_card_from_file()
    STORAGE_CREDIT_CARD_LOCK.release()
    return credit_card

def save_credit_card(credit_card):
    STORAGE_CREDIT_CARD_LOCK.acquire()
    save_credit_card_to_file(credit_card)
    STORAGE_CREDIT_CARD_LOCK.release()
    return

def load_product_from_file(filename=FULL_PRODUCT_FILENAME):
    try:
        with open(filename) as file:
            return json.load(file)
    except FileNotFoundError:
        return []

def save_product_to_file(product, filename=FULL_PRODUCT_FILENAME):
    with open(filename, "w") as file:
        json.dump(product, file, indent=4)

def load_credit_card_from_file(filename=FULL_CREDIT_FILENAME):
    try:
        with open(filename) as file:
            return json.load(file)
    except FileNotFoundError:
        return []

def save_credit_card_to_file(credit_card, filename=FULL_CREDIT_FILENAME):
    with open(filename, "w") as file:
        json.dump(credit_card, file, indent=2)