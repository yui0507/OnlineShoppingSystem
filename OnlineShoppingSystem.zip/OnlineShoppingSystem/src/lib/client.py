import re

from flask.json import jsonify
from .web_service_client import ws_client
from urllib.error import HTTPError
from werkzeug.exceptions import HTTPException
import json

SERVER = "localhost:5000"

def read_all_product(server=SERVER):
    return ws_client(f"http://{server}/api/products")

def query_product(id, server=SERVER):
    return ws_client(f"http://{server}/api/query/{id}", "GET")
    
def replenish_stock(id, data, server=SERVER):
    return ws_client(f"http://{server}/api/replenish/{id}", "POST", data)

def purchase_product(id, data, server=SERVER):
    return ws_client(f"http://{server}/api/purchase/{id}", "POST", data)

# def test(server=SERVER):
#     return ws_client(f"http://{server}/api/test/", "GET")
