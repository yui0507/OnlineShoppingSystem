import json
from urllib.request import Request, urlopen
from urllib.error import HTTPError

def ws_client(url, method=None, data=None):
    if not method:
        method = "POST" if data else "GET"
    if data:
        data = json.dumps(data).encode("utf-8")
    headers = {"Content-type": "application/json; charset=UTF-8"} \
                if data else {}
    req = Request(url=url, data=data, headers=headers, method=method)
    try:
        with urlopen(req) as resp:
            result = json.loads(resp.read().decode("utf-8"))
    except HTTPError as e:
        err_result = json.loads(e.read().decode("utf-8"))
        return err_result
    else:
        return result