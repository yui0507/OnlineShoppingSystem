import os, subprocess

this_file_dir = os.path.dirname(__file__)

test_proc = subprocess.Popen(
    ["python", "web_service_test.py"], cwd=f"{this_file_dir}/./test")
