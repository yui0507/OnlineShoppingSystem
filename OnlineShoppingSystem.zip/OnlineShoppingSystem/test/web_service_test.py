import json, os, subprocess, time, unittest
from urllib.error import HTTPError
from urllib.request import Request, urlopen
import threading

SERVER = "localhost:5000"

def ws_client(url, method=None, data=None):
    if not method:
        method = "POST" if data else "GET"
    if data:
        data = json.dumps(data).encode("utf-8")
    headers = {"Content-type": "application/json; charset=UTF-8"} \
                if data else {}
    req = Request(url=url, data=data, headers=headers, method=method)
    with urlopen(req) as resp:
        result = json.loads(resp.read().decode("utf-8"))
    return result

class TestProductServer(unittest.TestCase):
    # @classmethod
    # def setUpClass(cls):
    #     this_file_dir = os.path.dirname(__file__)
    #     cls.server_proc = subprocess.Popen(
    #         ["python", "web_service.py"], cwd=f"{this_file_dir}/../src")
    #     time.sleep(0.5)

    # @classmethod
    # def tearDownClass(cls):
        # cls.server_proc.terminate()

    # def test_create_todo_item(self):
    #     list_resp = ws_client(f"http://{SERVER}/api/todos")
    #     num_before_create = len(list_resp)
    #     create_resp = ws_client(f"http://{SERVER}/api/todos", "POST", {"desc": "create me"})
    #     self.assertEqual("create me", create_resp["desc"])
    #     list_resp = ws_client(f"http://{SERVER}/api/todos")
    #     self.assertEqual(num_before_create + 1, len(list_resp))
    #     self.assertIn(create_resp, list_resp)

    # def test_create_todo_error(self):
    #     try:
    #         ws_client(f"http://{SERVER}/api/todos", "POST", {"desc": " "})
    #         self.assertTrue(False)
    #     except HTTPError as e:
    #         self.assertEqual(400, e.code)
            
    # List of API ---------------------------------------------------
    # api read_all_product:
    #     f"http://{SERVER}/api/products"

    # api query_product:
    #     f"http://{SERVER}/api/query/{id}", "GET"
        
    # api replenish_stock
    #     f"http://{SERVER}/api/replenish/{id}", "POST", data

    # api purchase_product:
    #     f"http://{SERVER}/api/purchase/{id}", "POST", data

    # api test:
    #     f"http://{SERVER}/api/test/", "GET"
    # -----------------------------------------------------------------

    # 1. A query about a product returns the correct product attributes
    
    # "product_id" : 9,
    # "description" : "Use For Unit Test Do NOT Update the stock thanks",
    # "price" : 12699.0,
    # "stock" : 1
    def test_query_product(self):
        product_id = 10
        description = "Use For Unit Test Do NOT Update the stock thanks"
        price = 12699.0
        stock = 10
        list_resp = ws_client(f"http://{SERVER}/api/query/{product_id}")
        # product_id is +1 for user-friendly query, therefore -1 to match the server response
        self.assertEqual(product_id - 1, list_resp[1]["product_id"]) 
        self.assertEqual(description, list_resp[1]["description"])
        self.assertEqual(price, list_resp[1]["price"])
        self.assertEqual(stock, list_resp[1]["stock"])

    # 2. Buying a product with sufficient stock in the server succeeds and the quantity in stock is updated.
    def test_buy_product(self):
        product_id = 1
        quantity = "1"
        credit_card = "5678567856785678"
        data = {"quantity" : quantity, "credit_card" : credit_card}
        pro_resp = ws_client(f"http://{SERVER}/api/query/{product_id}")
        stock_before = pro_resp[1]["stock"]

        buy_resp = ws_client(f"http://{SERVER}/api/purchase/{product_id}", "POST", data)

        pro_resp = ws_client(f"http://{SERVER}/api/query/{product_id}")
        stock_after = pro_resp[1]["stock"]
        self.assertEqual(stock_before - int(quantity), stock_after)


    # 3. Buying a product with insufficient stock in the server fails and the quantity in stock remains unchanged.
    def test_buy_product_no_stock(self):
        product_id = 1
        quantity = "1000000000"
        credit_card = "5678567856785678"
        data = {"quantity" : quantity, "credit_card" : credit_card}
        
        pro_resp = ws_client(f"http://{SERVER}/api/query/{product_id}")
        stock_before = pro_resp[1]["stock"]
        try:
            buy_resp = ws_client(f"http://{SERVER}/api/purchase/{product_id}", "POST", data)
        except HTTPError as e:
            code = e.code
        finally:
            pro_resp = ws_client(f"http://{SERVER}/api/query/{product_id}")
            stock_after = pro_resp[1]["stock"]
            self.assertEqual(stock_before, stock_after)

    # 4. Replenishing a product updates the server’s quantity in stock.
    def test_replenish_stock(self):
        product_id = 1
        quantity = "1"
        data = {"stock" : quantity}
        pro_resp = ws_client(f"http://{SERVER}/api/query/{product_id}")
        stock_before = pro_resp[1]["stock"]

        buy_resp = ws_client(f"http://{SERVER}/api/replenish/{product_id}", "POST", data)

        pro_resp = ws_client(f"http://{SERVER}/api/query/{product_id}")
        stock_after = pro_resp[1]["stock"]
        self.assertEqual(stock_before + int(quantity), stock_after)

    # 5. When the product ID does not exist, the server returns the 404 status code.
    def test_product_id_not_found(self):
        product_id = 99999999
        try:
            pro_resp = ws_client(f"http://{SERVER}/api/query/{product_id}")
        except HTTPError as e:
            self.assertEqual(404, e.code)

    # 6. When some required input data are missing or invalid, the server returns the 400 status code.
    def test_replenish_data_empty(self):
        product_id = 1
        data = {"stock" : " "}
        try:
            buy_resp = ws_client(f"http://{SERVER}/api/replenish/{product_id}", "POST", data)
        except HTTPError as e:
            self.assertEqual(400, e.code)

        
    # 7. If two requests for buying the same product arrive almost simultaneously and 
    # the quantity in stock is insufficient for the second request, the server must not
    # mistakenly fulfill the second request
    def test_buy_simultaneously(self):
        status_result = 0
        product_id = 10
        quantity = "10"
        def buy_same_product():
            nonlocal status_result
            nonlocal product_id
            nonlocal quantity
            credit_card = "5678567856785678"
            data = {"quantity" : quantity, "credit_card" : credit_card}
            try:
                buy_resp = ws_client(f"http://{SERVER}/api/purchase/{product_id}", "POST", data)
                status_result += 200
                return buy_resp["status"]
            except HTTPError as e:
                status_result += 400
                return e.code

        p1 = threading.Thread(target=buy_same_product)
        p2 = threading.Thread(target=buy_same_product)
        p1.start()
        p2.start()
        p1.join()
        p2.join()
        self.assertEqual(600, status_result)
        data = {"stock" : quantity}
        buy_resp = ws_client(f"http://{SERVER}/api/replenish/{product_id}", "POST", data)

if __name__ == "__main__":
    unittest.main()