import os, subprocess

this_file_dir = os.path.dirname(__file__)
server_proc = subprocess.Popen(
    ["python", "web_service.py"], cwd=f"{this_file_dir}/./src")
test_proc = subprocess.Popen(
    ["python", "server.py"], cwd=f"{this_file_dir}/./src")